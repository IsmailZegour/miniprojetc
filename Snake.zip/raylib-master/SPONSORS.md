The following people has contributed with a generous donation to the raylib project.

## 🥇 Gold Contributors

...

## 🥈 Silver Contributors

 - Jonathan Johnson ([@ecton](https://github.com/ecton))
 - Eric J. ([@ProfJski](https://github.com/ProfJski))
 - Rudy Faile ([@rfaile313](https://github.com/rfaile313)) - https://rudyfaile.com/
 - devdad ([@devdad](https://github.com/devdad))
 - frithrah ([@frithrah](https://github.com/frithrah))

## 🥉 Bronze Contributors

 - minirop ([@minirop](https://github.com/minirop))
 - Daniel Gómez ([@Koocachookies](https://github.com/Koocachookies))
 - Sergio ([@anidealgift](https://github.com/anidealgift))
 - JFons ([@JFonS](https://github.com/JFonS))
 - Marc Agüera ([@maguera93](https://github.com/maguera93))
 - Pau Fernández ([@pauek](https://github.com/pauek))
 - Jens Pitkänen ([@neonmoe](https://github.com/neonmoe))
 - Snowminx ([@Gamerfiend](https://github.com/Gamerfiend))
 - NimbusFox ([@NimbusFox](https://github.com/NimbusFox))
 - Robin Mattheussen ([@romatthe](https://github.com/romatthe))
 - Rahul Nair ([@rahulunair](https://github.com/rahulunair)) 
 - Grant Haywood ([@cinterloper](https://github.com/cinterloper))
 - Terry Nguyen ([@terrehbyte](https://github.com/terrehbyte))
 - albatros-hmd ([@albatros-hmd](https://github.com/albatros-hmd))
 - Benjamin Stigsen ([@BenStigsen](https://github.com/BenStigsen))
 - Louis Johnson ([@louisgjohnson](https://github.com/louisgjohnson))
 - Dani Martin ([@danimartin82](https://github.com/danimartin82))
 - Tommi Sinivuo ([@TommiSinivuo](https://github.com/TommiSinivuo))
 - Joakim Wennergren ([@joakimwennergren](https://github.com/joakimwennergren))
 - Richard Urbanec ([@Poryg1](https://github.com/Poryg1))
 - pmgl ([@pmgl](https://github.com/pmgl))
 - cob ([@majorcob](https://github.com/majorcob))
 - Samuel Batista ([@gamedevsam](https://github.com/gamedevsam))
 - Alexandre Chêne ([@kooparse](https://github.com/kooparse))
 - daddio69 ([@daddio69](https://github.com/daddio69))
 
